# EggNest Burmese Game V3

ဒီ package မှာ Telegram bot backend + Burmese Mini App UI Demo ပါဝင်ပါတယ်။

## 1) Bot ကို Termux မှာ run
```bash
cd ~/storage/downloads/EggNest_Burmese_Game_V3
pip install -r requirements.txt
export BOT_TOKEN='BotFather မှ အသစ်ရထားသော token'
export ADMIN_ID='သင့် Telegram ID'
python bot.py
```

Token ကို chat/screenshot မပို့ပါနှင့်။ အရင် token ပေါက်ကြားခဲ့ပါက BotFather မှ revoke လုပ်ပြီး token အသစ်ယူပါ။

## 2) Mini App
`web/index.html` က Telegram Web App UI demo ဖြစ်ပါတယ်။ Telegram ကနေ တကယ်ဖွင့်ဖို့ HTTPS public hosting လိုပါတယ်။ Termux localhost တစ်ခုတည်းနဲ့ Telegram cloud ကနေ မဖွင့်နိုင်ပါ။

## 3) Video reward
Video ကြည့်ခြင်းအတွက် fake view/ad fraud မလုပ်ပါ။ Production မှာ တရားဝင် video/ad provider ရဲ့ reward/verification API နှင့်သာ ချိတ်ပါ။

## 4) Money/withdraw
ဒီ project က game points ကို အဓိကထားပါတယ်။ အလိုအလျောက် ငွေသား/crypto payout မပါပါ။ Withdrawal request ကို admin manual review အတွက်သာ သိမ်းပါတယ်။

## 5) Next production steps
- HTTPS hosting
- Bot ရဲ့ Web App button ကို Mini App URL နဲ့ချိတ်ခြင်း
- Server-side points validation (localStorage ကို production reward အတွက် မသုံးပါနှင့်)
- Real game API
- Authorized video/ad provider
- Admin dashboard
