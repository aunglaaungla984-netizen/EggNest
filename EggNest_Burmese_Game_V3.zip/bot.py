import os, sqlite3, time, threading
import telebot
from telebot import types

TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID", "0") or 0)
DB = "eggnest.db"

if not TOKEN:
    raise SystemExit("BOT_TOKEN မတွေ့ပါ။ Termux မှာ export BOT_TOKEN='သင်၏အသစ်ရထားသော token' လုပ်ပါ။")

bot = telebot.TeleBot(TOKEN, parse_mode="HTML")

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init():
    c = db()
    c.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY, username TEXT, points INTEGER DEFAULT 0,
        eggs INTEGER DEFAULT 0, level INTEGER DEFAULT 1, energy INTEGER DEFAULT 100,
        last_daily INTEGER DEFAULT 0, ref_by INTEGER DEFAULT 0)""")
    c.execute("""CREATE TABLE IF NOT EXISTS withdrawals(
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, points INTEGER,
        note TEXT, status TEXT DEFAULT 'pending', created INTEGER)""")
    c.execute("""CREATE TABLE IF NOT EXISTS tasks(
        id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, reward INTEGER, active INTEGER DEFAULT 1)""")
    c.execute("""CREATE TABLE IF NOT EXISTS claims(
        user_id INTEGER, task_id INTEGER, UNIQUE(user_id, task_id))""")
    c.commit(); c.close()

def user(uid, username=""):
    c=db(); r=c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not r:
        c.execute("INSERT INTO users(id,username) VALUES(?,?)",(uid,username or ""))
        c.commit()
        r=c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    elif username and r["username"] != username:
        c.execute("UPDATE users SET username=? WHERE id=?",(username,uid)); c.commit()
        r=c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    c.close(); return r

def menu():
    m=types.ReplyKeyboardMarkup(resize_keyboard=True)
    rows=[
        ["🏠 ပင်မစာမျက်နှာ","🐔 ကြက်ခြံ"],
        ["🥚 ဥစုမယ်","🎮 ဂိမ်းကစားမယ်"],
        ["🎬 ဗီဒီယိုကြည့်မယ်","🎁 နေ့စဉ်ဆု"],
        ["🎯 လုပ်ငန်းတာဝန်များ","👥 သူငယ်ချင်းဖိတ်မယ်"],
        ["💰 အမှတ်လက်ကျန်","🏪 ဆိုင်"],
        ["💸 ထုတ်ယူရန်","📖 အသုံးပြုနည်း"]
    ]
    for x in rows:m.row(*[types.KeyboardButton(v) for v in x])
    return m

@bot.message_handler(commands=["start"])
def start(msg):
    u=user(msg.from_user.id, msg.from_user.username)
    text=("🥚 <b>EggNest မှ ကြိုဆိုပါတယ်!</b>\n\n"
          "🎮 ဂိမ်းကစား၊ 🥚 ဥစု၊ 🎬 ဗီဒီယိုကဏ္ဍနှင့် လုပ်ငန်းတာဝန်များကနေ "
          "<b>ဂိမ်းအမှတ်</b> စုဆောင်းနိုင်ပါတယ်။\n\n"
          "⚠️ အမှတ်များသည် ဒီစနစ်အတွင်းသုံးရန်အတွက်သာ ဖြစ်ပြီး အလိုအလျောက် ငွေပေးချေမှု မရှိပါ။")
    bot.send_message(msg.chat.id,text,reply_markup=menu())

@bot.message_handler(commands=["myid"])
def myid(msg): bot.reply_to(msg,f"🆔 သင့် Telegram ID = <code>{msg.from_user.id}</code>")

def farm(chat):
    r=user(chat)
    need=max(100, 100 + (r["level"]-1)*25)
    txt=(f"🐔 <b>သင့်ကြက်ခြံ</b>\n\n"
         f"⭐ Level: {r['level']}\n⚡ Energy: {r['energy']}/{need}\n"
         f"🥚 ဥ: {r['eggs']}\n💰 အမှတ်: {r['points']}\n\n"
         "🥚 'ဥစုမယ်' ကိုနှိပ်ပြီး ဥစုနိုင်ပါတယ်။")
    bot.send_message(chat,txt,reply_markup=menu())

@bot.message_handler(func=lambda m:m.text=="🏠 ပင်မစာမျက်နှာ")
def home(m): start(m)

@bot.message_handler(func=lambda m:m.text=="🐔 ကြက်ခြံ")
def f(m): farm(m.chat.id)

@bot.message_handler(func=lambda m:m.text=="🥚 ဥစုမယ်")
def egg(m):
    r=user(m.from_user.id)
    if r["energy"] < 10:
        bot.reply_to(m,"⚡ Energy မလုံလောက်သေးပါ။ နောက်မှ ပြန်စမ်းပါ။",reply_markup=menu()); return
    c=db()
    pts=10
    c.execute("UPDATE users SET eggs=eggs+1, points=points+?, energy=energy-10 WHERE id=?",(pts,m.from_user.id))
    c.commit(); c.close()
    bot.send_message(m.chat.id,f"🥚 <b>ဥတစ်လုံး ရပါပြီ!</b>\n\n💰 +{pts} အမှတ်\n⚡ -10 Energy",reply_markup=menu())

@bot.message_handler(func=lambda m:m.text=="🎁 နေ့စဉ်ဆု")
def daily(m):
    r=user(m.from_user.id); now=int(time.time())
    if now-r["last_daily"]<86400:
        left=86400-(now-r["last_daily"]); h=left//3600; mi=(left%3600)//60
        bot.send_message(m.chat.id,f"⏳ ဒီနေ့ဆု ရယူပြီးပါပြီ။\nနောက်ထပ် {h} နာရီ {mi} မိနစ်နောက် ပြန်ယူနိုင်ပါတယ်။",reply_markup=menu()); return
    c=db(); c.execute("UPDATE users SET points=points+50,last_daily=? WHERE id=?",(now,m.from_user.id)); c.commit(); c.close()
    bot.send_message(m.chat.id,"🎁 <b>နေ့စဉ်ဆု +50 အမှတ် ရပါပြီ!</b>",reply_markup=menu())

@bot.message_handler(func=lambda m:m.text=="🎯 လုပ်ငန်းတာဝန်များ")
def tasks(m):
    r=user(m.from_user.id); c=db()
    ts=c.execute("SELECT * FROM tasks WHERE active=1").fetchall()
    if not ts:
        bot.send_message(m.chat.id,"🎯 လောလောဆယ် လုပ်ငန်းတာဝန် မရှိသေးပါ။",reply_markup=menu()); c.close(); return
    kb=types.InlineKeyboardMarkup()
    for t in ts:
        claimed=c.execute("SELECT 1 FROM claims WHERE user_id=? AND task_id=?",(r["id"],t["id"])).fetchone()
        kb.add(types.InlineKeyboardButton(("✅ " if claimed else "🎯 ")+t["title"]+f" (+{t['reward']})",callback_data=f"task:{t['id']}"))
    c.close(); bot.send_message(m.chat.id,"🎯 <b>လုပ်ငန်းတာဝန်များ</b>\nပြီးမြောက်ပြီးသားကို ထပ်မံဆုမပေးပါ။",reply_markup=kb)

@bot.callback_query_handler(func=lambda q:q.data.startswith("task:"))
def claim(q):
    tid=int(q.data.split(":")[1]); uid=q.from_user.id; c=db()
    t=c.execute("SELECT * FROM tasks WHERE id=? AND active=1",(tid,)).fetchone()
    if not t: c.close(); bot.answer_callback_query(q.id,"Task မရှိတော့ပါ။"); return
    try:
        c.execute("INSERT INTO claims(user_id,task_id) VALUES(?,?)",(uid,tid))
        c.execute("UPDATE users SET points=points+? WHERE id=?",(t["reward"],uid)); c.commit()
        bot.answer_callback_query(q.id,f"+{t['reward']} အမှတ် ရပါပြီ!")
    except sqlite3.IntegrityError:
        bot.answer_callback_query(q.id,"ဒီ Task ကို ဆုယူပြီးသားပါ။")
    c.close()

@bot.message_handler(func=lambda m:m.text=="👥 သူငယ်ချင်းဖိတ်မယ်")
def invite(m):
    me=bot.get_me()
    link=f"https://t.me/{me.username}?start=ref_{m.from_user.id}"
    bot.send_message(m.chat.id,f"👥 <b>သူငယ်ချင်းဖိတ်မယ်</b>\n\nသင့်ဖိတ်ခေါ်လင့်:\n<code>{link}</code>\n\nသူငယ်ချင်းအသစ် ဝင်လာလျှင် သတ်မှတ်ထားသော စနစ်အတိုင်း ဂိမ်းအမှတ်ရနိုင်ပါတယ်။",reply_markup=menu())

@bot.message_handler(func=lambda m:m.text=="💰 အမှတ်လက်ကျန်")
def bal(m):
    r=user(m.from_user.id); bot.send_message(m.chat.id,f"💰 <b>အမှတ်လက်ကျန်</b>\n\n💰 Points: {r['points']}\n🥚 Eggs: {r['eggs']}\n⭐ Level: {r['level']}",reply_markup=menu())

@bot.message_handler(func=lambda m:m.text=="🎮 ဂိမ်းကစားမယ်")
def game(m):
    bot.send_message(m.chat.id,"🎮 <b>ဂိမ်းကဏ္ဍ</b>\n\nMini App version မှာ ဥဖမ်းဂိမ်း၊ Energy၊ Level နဲ့ Animation တွေ ထည့်ထားပါတယ်။\n\nအခု version မှာ Demo အဖြစ် '🥚 ဥစုမယ်' ကို အသုံးပြုနိုင်ပါတယ်။",reply_markup=menu())

@bot.message_handler(func=lambda m:m.text=="🎬 ဗီဒီယိုကြည့်မယ်")
def video(m):
    bot.send_message(m.chat.id,"🎬 <b>ဗီဒီယိုကဏ္ဍ</b>\n\nဗီဒီယိုကြည့်ပြီး ဂိမ်းအမှတ်ရစေမယ့်စနစ်ကို Mini App version မှာ ထည့်နိုင်ပါတယ်။\n\n⚠️ တကယ်ကြည့်ရှုကြောင်း အတည်ပြုခြင်းနဲ့ Reward စနစ်က တရားဝင် video/ad provider စည်းမျဉ်းများနှင့် ကိုက်ညီရပါမယ်။",reply_markup=menu())

@bot.message_handler(func=lambda m:m.text=="🏪 ဆိုင်")
def shop(m):
    bot.send_message(m.chat.id,"🏪 <b>EggNest ဆိုင်</b>\n\nဒီနေရာမှာ ဂိမ်းအမှတ်နဲ့ ရယူနိုင်မယ့် in-game rewards တွေ ထည့်နိုင်ပါတယ်။",reply_markup=menu())

@bot.message_handler(func=lambda m:m.text=="💸 ထုတ်ယူရန်")
def wd(m):
    bot.send_message(m.chat.id,"💸 <b>အမှတ်ထုတ်ယူရန်</b>\n\nအမှတ်ကို ငွေသားအဖြစ် အလိုအလျောက်ပြောင်းပေးတဲ့စနစ် မပါသေးပါ။ Admin စစ်ဆေးမှု/တရားဝင် reward provider တစ်ခုရှိပါကသာ manual review စနစ်နဲ့ ဆက်တည်ဆောက်နိုင်ပါတယ်။\n\nဥပမာ: <code>/withdraw 1000 KPay/Reward note</code>",reply_markup=menu())

@bot.message_handler(commands=["withdraw"])
def withdraw(m):
    p=m.text.split(maxsplit=2)
    if len(p)<2 or not p[1].isdigit(): bot.reply_to(m,"သုံးနည်း: <code>/withdraw အမှတ် မှတ်ချက်</code>"); return
    pts=int(p[1]); note=p[2] if len(p)>2 else ""
    r=user(m.from_user.id)
    if pts<=0 or pts>r["points"]: bot.reply_to(m,"❌ သင့်အမှတ်လက်ကျန် မလုံလောက်ပါ။"); return
    c=db(); c.execute("UPDATE users SET points=points-? WHERE id=?",(pts,m.from_user.id))
    cur=c.execute("INSERT INTO withdrawals(user_id,points,note,created) VALUES(?,?,?,?)",(m.from_user.id,pts,note,int(time.time())))
    wid=cur.lastrowid; c.commit(); c.close()
    bot.reply_to(m,f"📨 ထုတ်ယူရန်တောင်းဆိုချက် #{wid} ကို ပို့ပြီးပါပြီ။ Admin စစ်ဆေးပေးပါမယ်။")
    if ADMIN_ID:
        bot.send_message(ADMIN_ID,f"📨 <b>Withdrawal #{wid}</b>\nUser: <code>{m.from_user.id}</code>\nPoints: {pts}\nNote: {note}\n\n/admin မှ စစ်ဆေးပါ။")

@bot.message_handler(func=lambda m:m.text=="📖 အသုံးပြုနည်း")
def guide(m):
    bot.send_message(m.chat.id,"📖 <b>အသုံးပြုနည်း</b>\n\n1️⃣ ကြက်ခြံထဲက Energy ကိုကြည့်ပါ။\n2️⃣ ဥစုမယ်ကိုနှိပ်ပြီး Points စုပါ။\n3️⃣ နေ့စဉ်ဆုယူပါ။\n4️⃣ Tasks ပြီးအောင်လုပ်ပါ။\n5️⃣ သူငယ်ချင်းဖိတ်နိုင်ပါတယ်။\n6️⃣ Mini App version မှာ Game/Video UI ကို အသုံးပြုနိုင်ပါတယ်။\n\n⚠️ Points တွေကို အမြဲတမ်းငွေသားအဖြစ်ပြောင်းပေးမယ်လို့ မဆိုထားပါ။",reply_markup=menu())

@bot.message_handler(commands=["admin"])
def admin(m):
    if m.from_user.id!=ADMIN_ID: return
    c=db(); n=c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]; w=c.execute("SELECT COUNT(*) n FROM withdrawals WHERE status='pending'").fetchone()["n"]; c.close()
    bot.send_message(m.chat.id,f"🛠 <b>Admin Panel</b>\n\n👥 Users: {n}\n📨 Pending Withdrawals: {w}\n\nTask ထည့်ရန်: <code>/addtask ခေါင်းစဉ် | ဆု</code>\nTask ပိတ်ရန်: <code>/disabletask ID</code>\nWithdrawal approve: <code>/wdapprove ID</code>\nWithdrawal reject: <code>/wdreject ID</code>")

@bot.message_handler(commands=["addtask"])
def addtask(m):
    if m.from_user.id!=ADMIN_ID:return
    raw=m.text[len("/addtask"):].strip()
    if "|" not in raw: bot.reply_to(m,"သုံးနည်း: <code>/addtask Task name | 100</code>"); return
    title,reward=map(str.strip,raw.split("|",1))
    if not reward.isdigit(): bot.reply_to(m,"Reward ကို ဂဏန်းနဲ့ရေးပါ။"); return
    c=db(); c.execute("INSERT INTO tasks(title,reward) VALUES(?,?)",(title,int(reward))); c.commit(); c.close()
    bot.reply_to(m,"✅ Task ထည့်ပြီးပါပြီ။")

@bot.message_handler(commands=["disabletask"])
def disabletask(m):
    if m.from_user.id!=ADMIN_ID:return
    p=m.text.split()
    if len(p)!=2 or not p[1].isdigit(): bot.reply_to(m,"သုံးနည်း: <code>/disabletask ID</code>"); return
    c=db(); c.execute("UPDATE tasks SET active=0 WHERE id=?",(int(p[1]),)); c.commit(); c.close(); bot.reply_to(m,"✅ Task ပိတ်ပြီးပါပြီ။")

@bot.message_handler(commands=["wdapprove"])
def wda(m):
    if m.from_user.id!=ADMIN_ID:return
    p=m.text.split()
    if len(p)!=2 or not p[1].isdigit(): return
    c=db(); c.execute("UPDATE withdrawals SET status='approved' WHERE id=? AND status='pending'",(int(p[1]),)); c.commit(); c.close(); bot.reply_to(m,"✅ Withdrawal ကို approved လုပ်ပြီးပါပြီ။ ငွေပေးချေမှုကို တရားဝင် provider/admin process နဲ့ ဆက်လုပ်ပါ။")

@bot.message_handler(commands=["wdreject"])
def wdr(m):
    if m.from_user.id!=ADMIN_ID:return
    p=m.text.split()
    if len(p)!=2 or not p[1].isdigit(): return
    c=db(); r=c.execute("SELECT * FROM withdrawals WHERE id=? AND status='pending'",(int(p[1]),)).fetchone()
    if not r: c.close(); bot.reply_to(m,"❌ Pending request မတွေ့ပါ။"); return
    c.execute("UPDATE withdrawals SET status='rejected' WHERE id=?",(int(p[1]),))
    c.execute("UPDATE users SET points=points+? WHERE id=?",(r["points"],r["user_id"])); c.commit(); c.close()
    bot.reply_to(m,"↩️ Reject လုပ်ပြီး အမှတ်ပြန်ထည့်ပေးလိုက်ပါပြီ။")

init()
print("EggNest Burmese Bot is running...")
bot.infinity_polling(skip_pending=True)
