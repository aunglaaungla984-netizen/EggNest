const tg=window.Telegram?.WebApp; if(tg){tg.ready();tg.expand();}
let s=JSON.parse(localStorage.getItem("eggnest_demo")||'{"points":0,"eggs":0,"energy":100,"level":1}');
function save(){localStorage.setItem("eggnest_demo",JSON.stringify(s));render()}
function render(){points.textContent=s.points;eggs.textContent=s.eggs;energy.textContent=s.energy;level.textContent="Lv."+s.level}
egg.onclick=()=>{if(s.energy<10){msg.textContent="⚡ Energy မလုံလောက်ပါ";return}s.eggs++;s.points+=10;s.energy-=10;if(s.points>=s.level*200)s.level++;msg.textContent="🥚 +10 အမှတ် ရပါပြီ!";save()}
function daily(){s.points+=50;msg.textContent="🎁 Demo နေ့စဉ်ဆု +50";save()}
function game(){msg.textContent="🎮 ဥဖမ်းဂိမ်း Demo — ဥကို အမြန်နှိပ်ပြီး Points စုပါ!"}
function video(){msg.textContent="🎬 Video Demo — Reward စနစ်ကို တရားဝင် video/ad provider နဲ့ ချိတ်ဆက်ရပါမယ်။"}
function tasks(){msg.textContent="🎯 Tasks ကို Telegram Bot backend မှာ စီမံနိုင်ပါတယ်။"}
function invite(){msg.textContent="👥 Telegram Bot မှာ သင့် referral link ကို ရယူနိုင်ပါတယ်။"}
function shop(){msg.textContent="🏪 Shop — in-game rewards များ ထည့်နိုင်ပါတယ်။"}
render();